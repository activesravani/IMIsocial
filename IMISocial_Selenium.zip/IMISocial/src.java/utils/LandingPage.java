package utils;


import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LandingPage extends JavaScriptImp{
	public String URL = "https://qa.davincisocial.com/";
	public String forgotPasswordURL = "https://qa.davincisocial.com/Console/ForgotPassword";

	String userName = "input#EmailAddress";
	String nextBtn = "btnNext";
	String passWord = "input#Password";
	String signInButton = "//*[@id='container']/div[1]/form/div[3]/input";
	String selectedConsoleOption = "//*[@id='SectionSelected']";
	String ConsoleList = "select#SectionSelected";
	String ConsoleOptions = "//*[@id='SectionSelected']/option";
	String fieldValidationError = "field-validation-error";
	String summaryError = "validation-summary-errors";
	String summaryErrorText = "li";
	String forgotPassword = "a.forgot";
	String help = "a.openDialog.help-dialog";
	String existingLogin = "div#container form";
	String existingLoginYes = "//*[@id='container']/div[1]/form/div[2]/input[1]";
	String appLogo = "#nav>img";

	
	
	public String currentURL(){
		String currentURL=null;
		try{
			currentURL = driver.getCurrentUrl();

		}catch(Exception e){
			e.printStackTrace();
		}
		return currentURL;
	}
	
	public void landingPage() {
		  driver.get(URL);
	  }
	
	
	  public void Consoleselection(String console){
		  WebElement dropdown = elementByCss(ConsoleList);
		  dropdown.click();
		  List<WebElement> consoles = elementsByXpath(ConsoleOptions); 
		  for(WebElement name:consoles){
			  if(name.getText().equals(console)){
				  name.click();
			  }
		  }
	  }
	  
	  
	  public void Login(String uname,String pwd){
		  try{
			  sendKeys(elementByCss(userName),uname);
			  sendKeys(elementByCss(passWord),pwd);
			  elementByXpath(signInButton).click();	
			  elementVisibilityWait(elementByCss(appLogo));
		  }catch(Exception e){
			  e.printStackTrace();
		  }
	  }
	  public void bbcLogin(String uname,String pwd){
		  try{
			  sendKeys(elementByCss(userName),uname);
			  elementById(nextBtn).click();
			  Consoleselection("Admin Console");
			  elementVisibilityWait(elementByCss(passWord));
			  sendKeys(elementByCss(passWord),pwd);
			  elementById(signInButton).click();	
			  elementVisibilityWait(elementByCss(appLogo));
		  }catch(Exception e){
			  e.printStackTrace();
		  }
	  }
	  
	  
	  
	  public void clickFunction(WebElement element){
		  try{
			  if(element.isDisplayed() && element.isEnabled()){
				  element.click();
				}else if((element.isDisplayed() && element.isEnabled()==false)){
					System.out.println("element is not enabled");
				}else{
					System.out.println("element itself is not displaying");
				}
		  }catch(Exception e){
			  e.printStackTrace();
		  }
	  }
	  
	  public void pageRefresh(){
		  try{
			  driver.navigate().refresh();
		  }catch(Exception e){
			  e.printStackTrace();
		  }
	  }
	  public String loginPageSummaryValidationError(){
			String error =null;
			try{
				elementVisibilityWait(elementByClass(summaryError));
				if(elementByClass(summaryError).isDisplayed()){
					error = elementByClass(summaryError).getText();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
			return error;
		}
	  public String loginPageFieldValidationError(){
			String error =null;
			try{
				elementVisibilityWait(elementByClass(fieldValidationError));
				if(elementByClass(fieldValidationError).isDisplayed()){
					error = elementByClass(fieldValidationError).getText();
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
			return error;
		}
	  
	  public void forgotPasswordlinkClick(){
		  try{
			  elementVisibilityWait(elementByCss(forgotPassword));
				if(elementByCss(forgotPassword).isDisplayed() && elementByCss(forgotPassword).isEnabled() ){
					elementByCss(forgotPassword).click();
				}					
				
			}catch(Exception e){
				e.printStackTrace();
			}  
	  }
	  public void helplinkClick(){
		  try{
			  
			  elementVisibilityWait(elementByCss(help));
				if(elementByCss(help).isDisplayed() && elementByCss(help).isEnabled() ){
					elementByCss(help).click();
				}					
			}catch(Exception e){
				e.printStackTrace();
			}  
	  }
	  
	  public void closeDriverSession(){
		  driver.close();
	  }

}
