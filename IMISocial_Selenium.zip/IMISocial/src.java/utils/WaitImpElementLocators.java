package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitImpElementLocators extends WebElementsLocators{
	
	
	public void elementTextCheck(WebElement element,String Text){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.textToBePresentInElement(element, Text));
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	
	public void elementVisibilityWait(WebElement element){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
