package utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class DriverProperties {
	public WebDriver driver;
	public String driverPath = System.getProperty("user.dir")+"/JarFiles/";
	
	
	@BeforeTest
	public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver_win32/chromedriver.exe");
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
	  wait.pollingEvery(1, TimeUnit.SECONDS);
	  wait.withTimeout(60, TimeUnit.SECONDS);
	}
	
	@AfterTest
	public void afterClass() {
	  driver.quit();
	}

}
