package utils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HelpDialog extends LandingPage{
	By helpDiaolgbox = By.cssSelector("body>div.ui-dialog.ui-widget.ui-widget-content.ui-corner-all.ui-front.ui-dialog-buttons");
	By dialogLabel = By.className("dialog_label");
	By phoneNumber = By.cssSelector("#contentDiv>br:nth-child(2)");
	By email = By.cssSelector("#contentDiv>br:nth-child(3)");

	

	public String dialogLabelText(){
		String text = null;
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(helpDiaolgbox));
			if(driver.findElement(dialogLabel).isDisplayed()){
				text=driver.findElement(dialogLabel).getText();		
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}
	
	public String phoneNumberText(){
		String text = null;
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(helpDiaolgbox));
			if(driver.findElement(phoneNumber).isDisplayed()){
				text=driver.findElement(phoneNumber).getText();		
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}
	
	public String emailText(){
		String text = null;
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(helpDiaolgbox));
			if(driver.findElement(email).isDisplayed()){
				text=driver.findElement(email).getText();		
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}
	
}
