package utils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JavaScriptImp extends WaitImpElementsLocators{
	 
	public void newTab(){
		try{
			Actions actions = new Actions(driver);
			actions.sendKeys(Keys.CONTROL+"t").perform();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementClick(WebElement element){
		try{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", element);
		}catch(Exception e){
			
		}
	}
	
		
	public void pageScrollToElement(WebElement element){
		try{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].scrollIntoView(true);",element);

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void pageScrollToElement(WebElement element, String text){
		try{
			if(element.getText().contains(text)){
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].scrollIntoView(true);",element);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void scrollingToBottomofAPage() {
		 
		 try{
			 JavascriptExecutor executor = (JavascriptExecutor)driver;
			 executor.executeScript("window.scrollTo(0, document.body.scrollHeight)");

			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	
	public void scrolltoPageEnd(){
		try{
			Actions actions = new Actions(driver);
			actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void scrolltoPageEnd(WebElement element){
		try{
			int scroll_count=1;
			do
		    {
				element.sendKeys(Keys.PAGE_DOWN);
				scroll_count++;
				System.out.println(scroll_count);
		    }
		    while(scroll_count<30);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void scrolltoLastElement(WebElement element){
		try{
			int y = element.getLocation().getY();
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollTo(0,"+y+")");
					
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void mouseHoverElement(WebElement element){
		try{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].mouseOver()", element); 
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void scrollingToTopofAPage() {
		 
		 try{
			 JavascriptExecutor executor = (JavascriptExecutor)driver;
			 executor.executeScript("window.scrollTo(document.body.scrollHeight,0)");

			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	public void mouseHover(WebElement element){
		try{
			Actions action = new Actions(driver);
	        action.moveToElement(element).build().perform();
		}catch(Exception e){
			e.printStackTrace();
		}
  
	}
	
	public void scrolltoPageInfo(){
		try{
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.getElementById('adminTable_info').scrollIntoView(true);");
		}catch(Exception e){
			e.printStackTrace();
		}
	}	
	
		
	public void sendKeys(WebElement element,String value){
		try{
			if(element.isDisplayed() && element.isEnabled()){
				if(element.getText()==""){
					element.sendKeys(value);
				}else{
					element.clear();
					element.sendKeys(value);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void webDriverWait(WebElement element, String Text){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.textToBePresentInElement(element, Text));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void sendKeysWebElement(WebElement element, String text){
		try{
			JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
			myExecutor.executeScript("arguments[0].value=textw;", element);
			driver.quit();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
