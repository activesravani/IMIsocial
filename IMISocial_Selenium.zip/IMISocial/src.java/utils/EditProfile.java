package utils;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class EditProfile extends HomePage{
	By breadCrumb = By.className("breadcrumb");
	By breadCrumbLinks = By.cssSelector("#content-inner>form>ul>li>a");
	By breadCrumbSelectedLink = By.className("selectedPage");
	By fieldsLabels = By.cssSelector("div.editor-label>label");
	By fieldsValue = By.cssSelector("div.editor-field>input");
	By fieldValidationErrorText = By.tagName("span");
	By saveButton = By.xpath("//*[@value='Save']");

	
	public List<String> breadCrumbLinkText(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(breadCrumb).isDisplayed()){
				List<WebElement> links = driver.findElements(breadCrumbLinks);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean breadCrumbLinksText(String text){
		boolean linkTextPresence = false;
		try{
			List<String> links = breadCrumbLinkText();
			for(String link:links){
				if(link.equals(text)){
					linkTextPresence=true;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return linkTextPresence;
	}
	
	public String breadCrumbSelectedLinkText(){
		String slectedLink = null;
		try{
			if(driver.findElement(breadCrumb).isDisplayed()){
				slectedLink = driver.findElement(breadCrumbSelectedLink).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return slectedLink;
	}
	
	public List<String> labelsText()    {
		List<String> strings = new ArrayList<String>();
		try{
			List<WebElement> labelsList = driver.findElements(fieldsLabels);
			for(WebElement e : labelsList){
			    strings.add(e.getText());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean lableCheck(String text){
		boolean labelPresence = false;
		try{
			List<String> strings = labelsText();
			for(String label:strings){
				if(label.equals(text)){
					labelPresence=true; 
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return labelPresence;
	}
	
	public void fieldValue(String name,String text){
		try{
			List<WebElement> fieldsList = driver.findElements(fieldsValue);
			for(WebElement e : fieldsList){
				if(e.getAttribute("name").equals(name)){
					sendKeys(e,text);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String fieldValidationErrorString(String text){
		String error =null;
		try{
			clickFunction(driver.findElement(saveButton));
			List<WebElement> errors = driver.findElements(By.className(fieldValidationError));
			for(WebElement e : errors){
				if(e.findElement(fieldValidationErrorText).getText().equals(text)){
					error = e.findElement(fieldValidationErrorText).getText();
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return error;
	}

}
