package utils;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage extends LandingPage {
	/*public String pickVersion = "https://qa.davincisocial.com/campaign/PickVersion";
	public String campaignURL = "https://qa.davincisocial.com/Campaign/Index";
	public String curationURL = "https://qa.davincisocial.com/Console/Index";
	public String adminURL = "https://qa.davincisocial.com/Admin/AdminConsole";
*/
	public String pickVersion = "http://bbc.davincisocial.com/campaign/PickVersion";
	public String campaignURL = "http://bbc.davincisocial.com/Campaign/Index";
	public String curationURL = "http://bbc.davincisocial.com/Console/Index";
	public String adminURL = "http://bbc.davincisocial.com/admin/adminConsole";

	
	By menuLinks = By.cssSelector("#menu-links");
	By menuList = By.cssSelector("#menu-links > ul > li");
	By menuOptions = By.cssSelector("#menu-links > ul > li >a");
	By adminDashboard = By.cssSelector("div#content-inner h1");
	By campaignDashboard = By.cssSelector("#dtDashboard > tbody");
	By campaignsListNull = By.cssSelector("table#dtDashboard td");
	By campaignDashboardCSV = By.xpath("//*[@id='ZeroClipboard_TableToolsMovie_1']");
	By dashBoardLink = By.cssSelector("div#menu-links li:nth-child(1) > a");
	By winnerHistoryLink = By.xpath("//*[@id='menu-title-winner-dashboard']/span");
	By winnerHistorycaption = By.xpath("//*[@id='page-wrapper']/div/div[3]/div[1]/div");
	
	
	public By pageHeader = By.tagName("h1");
	
	
	By sideMenuOptions = By.xpath("//*[@href]/span");
	
	By adminShortcodesLink = By.cssSelector("div#ShortCodes");
	
	By curationBody = By.xpath("//*[@id='container']");
	By curationFeed = By.id("column-outbound");
	
	
	
	public void PickVersion(){
		try{
			if(currentURL().equals(pickVersion)){
				driver.get(campaignURL);
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.invisibilityOfElementLocated(campaignDashboardCSV));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void backtoCampaign(String url){
		try{
			
			if(driver.getCurrentUrl().equals(url)){
				System.out.println(driver.getTitle());
				if(url.equals(curationURL)){
					WebDriverWait wait = new WebDriverWait(driver, 20);
					wait.until(ExpectedConditions.visibilityOfElementLocated(curationFeed));
				}
				if(url.equals(adminURL)){
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.visibilityOfElementLocated(adminShortcodesLink));
				}
				MenuLinkCheck("Campaign Console");
				PickVersion();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void consolePage(){
		try{
			if(driver.getCurrentUrl().equals(curationURL)){
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.visibilityOfElementLocated(curationFeed));
			}
			else if(driver.getCurrentUrl().equals(adminURL)){
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.invisibilityOfElementLocated(adminShortcodesLink));
			}else if(driver.getCurrentUrl().equals(campaignURL)){
				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.visibilityOfElementLocated(campaignDashboardCSV));
			}else{
				System.out.println(driver.getCurrentUrl());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void MenuLinks(){
		try{
			List<WebElement> links = driver.findElements(menuList); 
			  for(WebElement name:links){
				  mouseHover(name);
				  System.out.println(name.getAttribute("title"));			  
			  }
		}catch(Exception e){
			
		}
	}
	
	public void SideMenuLinks(){
		try{
			List<WebElement> links = driver.findElements(sideMenuOptions); 
			System.out.println(links.size());
			  for(WebElement name:links){
				  System.out.println(name.getText());	  
			  }
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void MenuLinkCheck(String link){
		try{
			List<WebElement> links = driver.findElements(menuList); 
			  for(WebElement name:links){
				  if(name.getText().equals(link)){
					  name.click();
				  }
			  }
		}catch(Exception e){
			
		}
	}
	
	public void logOff(){
		try{
			List<WebElement> links = driver.findElements(menuList); 
			  for(WebElement name:links){
				  if(name.getText().equals("Log Off")){
					  name.click();
					  elementVisibilityWait(elementByCss(signInButton));

				  }
			  }
		}catch(Exception e){
			
		}
	}
	
	public void dashBoardPage(){
		try{
			driver.findElement(dashBoardLink).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(curationFeed));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void winnerHistoryPage(){
		try{
			mouseHover(driver.findElement(winnerHistoryLink));
			driver.findElement(winnerHistoryLink).click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(winnerHistorycaption));
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String pageHeaderText(){
		String header = null;
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
			header = driver.findElement(pageHeader).getText();
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	
}
