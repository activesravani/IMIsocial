package utils;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class WebElementsLocators extends WebElementLocators{

	
	public List<WebElement> elementsByCss(String css){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.cssSelector(css));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsById(String id){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.id(id));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByName(String name){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.name(name));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByTagName(String name){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.tagName(name));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByXpath(String xpath){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.xpath(xpath));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByClass(String classn){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.className(classn));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByLink(String text){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.linkText(text));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByPartialLink(String text){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.partialLinkText(text));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByIdContains(String text){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.xpath("//span[contains(@id,"+text+")]"));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	
	public List<WebElement> elementsByClassContains(String text){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.xpath("//span[contains(@class,"+text+")]"));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	
	public List<WebElement> elementsByStartswithId(String text){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.xpath("//a[starts-with(@id,"+text+")]"));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}
	
	public List<WebElement> elementsByStartswithClass(String text){
		List<WebElement> elements = new ArrayList<WebElement>();
		try{
			List<WebElement> links = driver.findElements(By.xpath("//a[starts-with(@class,"+text+")]"));
			for(WebElement link:links){
				elements.add(link);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return elements;
	}

}
