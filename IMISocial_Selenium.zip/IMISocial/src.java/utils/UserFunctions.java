package utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserFunctions {
	public String currentTime(){
		String format=null;
		try{
			DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
			Date date = new Date();
			format=dateFormat.format(date);
		}catch(Exception e){
			e.printStackTrace();
		}
		return format;
	}
	
	public int randomNumber(){
		int number = 0;
		try{
			number= (int) (Math.random()*10000);
		}catch(Exception e){
			e.printStackTrace();
		}
		return number;
	}
	
	public long timeMilliSeconds(){
		long time=0;
		try{
			time=System.currentTimeMillis();
		}catch(Exception e){
			e.printStackTrace();
		}
		return time;
	}
}
