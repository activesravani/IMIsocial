package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class WebElementLocators extends DriverProperties {
	
	public WebElement elementById(String id){
		WebElement element = null;
		try{
			element = driver.findElement(By.name(id));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	
	public WebElement elementByName(String name){
		WebElement element = null;
		try{
			element = driver.findElement(By.name(name));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByXpath(String xpath){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath(xpath));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByTag(String tag){
		WebElement element = null;
		try{
			element = driver.findElement(By.tagName(tag));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByCss(String css){
		WebElement element = null;
		try{
			element = driver.findElement(By.cssSelector(css));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByClass(String classname){
		WebElement element = null;
		try{
			element = driver.findElement(By.className(classname));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByLink(String linktext){
		WebElement element = null;
		try{
			element = driver.findElement(By.linkText(linktext));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByPartialLink(String linktext){
		WebElement element = null;
		try{
			element = driver.findElement(By.partialLinkText(linktext));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByIdContains(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//a[contains(@id,"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByClassContains(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//span[contains(@class,"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByNameContains(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//span[contains(@name,"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByTextContains(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//a[contains(text(),"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByStartswithId(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//a[starts-with(@id,"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByStartswithClass(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//a[starts-with(@class,"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public WebElement elementByText(String text){
		WebElement element = null;
		try{
			element = driver.findElement(By.xpath("//a[contains(text(),"+text+")]"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return element;
	}
	
	public void frameByName(String name){
		try{
			driver.switchTo().frame(name);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
