package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Logger;

public class TestBaseSetup {

	public static WebDriver driver;
	private final Logger log = Logger.getLogger(TestBaseSetup.class.getName());
	private FileInputStream  data = null;
	private Properties q = null;
	
	@BeforeClass
	public void setDriver() throws IOException{
		
		if (q.getProperty("setup.browser").equalsIgnoreCase("Firefox")) {
			driver = new FirefoxDriver();
		} else if (q.getProperty("setup.browser").equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/chromedriver_win32/chromedriver.exe");
			driver = new ChromeDriver();
		} /*else if (p.getProperty("browser.type").equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.chrome.driver", "/home/beehyv/Downloads/chromedriver");
			driver = new InternetExplorerDriver();
		}*/
		log.info("Open Driver");
		driver.manage().window().maximize();
	}
	
	@AfterClass
	public void CloseDriver(){
		driver.quit();
		log.info("Browser is successfully terminated");
	}
	
	public void screenShot(String name){
		try{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, new File(name));
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
	}
	
	public void newTab(){
		try{
			 ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
			 driver.switchTo().window(tabs.get(1));
			}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
