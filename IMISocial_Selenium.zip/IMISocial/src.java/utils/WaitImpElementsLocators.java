package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitImpElementsLocators extends WaitImpElementLocators{
	
	
	public void elementsVisibilityWaitByName(String name){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByName(name)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitById(String id){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsById(id)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void elementsVisibilityWaitByXpath(String xpath){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByXpath(xpath)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByCss(String css){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByCss(css)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByTag(String tag){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByCss(tag)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByClass(String classn){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByClass(classn)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByLink(String linktxt){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByLink(linktxt)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByPartialLink(String linktxt){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElements(elementsByPartialLink(linktxt)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void elementsVisibilityWaitByIdLocator(String id){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id(id)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByClassLocator(String classn){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className(classn)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void elementsVisibilityWaitByCssLocator(String css){
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(css)));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}

