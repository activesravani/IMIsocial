package utils;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FotgotPassword extends LandingPage{
	By actionHeader = By.tagName("h3");
	By fieldsLabels = By.cssSelector("div.editor-label>label");
	By fieldsValue = By.cssSelector("div.editor-field>input");
	By fieldValidationErrorText = By.tagName("span");
	By sendReminderBtn = By.cssSelector("div.buttonRow>input");
	By backBtn = By.cssSelector("div.buttonRow>a");

	
	public List<String> labelsText()    {
		List<String> strings = new ArrayList<String>();
		try{
			List<WebElement> labelsList = driver.findElements(fieldsLabels);
			for(WebElement e : labelsList){
			    strings.add(e.getText());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean lableCheck(String text){
		boolean labelPresence = false;
		try{
			List<String> strings = labelsText();
			for(String label:strings){
				if(label.equals(text)){
					labelPresence=true; 
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return labelPresence;
	}
	
	public void fieldValue(String name,String text){
		try{
			List<WebElement> fieldsList = driver.findElements(fieldsValue);
			for(WebElement e : fieldsList){
				if(e.getAttribute("name").equals(name)){
					sendKeys(e,text);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String fieldValidationErrorString(){
		String error =null;
		try{
			clickFunction(driver.findElement(sendReminderBtn));
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(fieldValidationError)));
			if(driver.findElement(By.className(fieldValidationError)).isDisplayed()){
				error = driver.findElement(By.className(fieldValidationError)).getText();
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return error;
	}
	public String actionHeaderText(){
		String text =null;
		try{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(actionHeader));
			if(driver.findElement(actionHeader).isDisplayed()){
				text = driver.findElement(actionHeader).getText();
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}

	public void backButton(){
		try{
			clickFunction(driver.findElement(backBtn));
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(fieldValidationError)));
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
