package campaignConsole;

import org.openqa.selenium.WebElement;
import utils.HomePage;

public class Dashboard extends HomePage{
	
	String frame = "CampaignFrame";
	String newcampaign = "#menu-title-new-campaign > span.menu-title";
	String sidemenuoptions = "//*[@class='menu-title']";
	String submenu = "submenu";
	String detailsTabHeader = "//*[@id='form']/div/div/div[1]/h3";
	
	
	
	public void newCampaignType(String type){
		try{
			elementByClassContains("submenu");
			for(WebElement element : elementsByClassContains(submenu)){
				if(element.getText().contains(type)){
					element.click();
					elementVisibilityWait(elementByCss(newcampaign));
					break;
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void sideMenuOptionSelection(String value){
		try{
			frameByName(frame);
			elementVisibilityWait(elementByXpath(sidemenuoptions));
			for(WebElement option:elementsByXpath(sidemenuoptions)){
				if(option.getText().equals(value)){
					System.out.println(option.getText());
					option.click();
					elementVisibilityWait(elementByCss(newcampaign));
					break;

				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
