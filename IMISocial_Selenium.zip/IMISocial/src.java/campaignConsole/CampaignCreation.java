package campaignConsole;

import org.openqa.selenium.WebElement;

public class CampaignCreation extends Dashboard{
	String campaignName = "CampaignName";
	String orgName = "#OrganisationId>option";
	String brandName = "#BrandId>option";
	String teamName = "#TeamId>option";
	String smsIbShortCode = "#SMSInboundIdentifier>option";
	String smsOBTariff = "#SMSOutboundIdentifier>option";
	String smsSproofResponder = "#SMSSpoofResponder";
	
	
	public String detailsTab(){
		String title =null;
		try{
			if(elementByXpath(detailsTabHeader).getText().contains("Details")){
				title = elementByXpath(detailsTabHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return title;
	}
	
	public void campaignNameEntry(String name){
		try{
			elementById(campaignName).sendKeys(name);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void orgSelection(String name){
		try{
			for(WebElement orgn:elementsByCss(orgName)){
				if(orgn.getText().contains(name)){
					orgn.click();
					elementsVisibilityWaitByCssLocator(brandName);			
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void brandSelection(String name){
		try{
			for(WebElement brand:elementsByCss(brandName)){
				if(brand.getText().contains(name)){
					brand.click();
					elementsVisibilityWaitByCssLocator(teamName);			
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void teamSelection(String name){
		try{
			for(WebElement team:elementsByCss(teamName)){
				if(team.getText().contains(name)){
					team.click();
					elementsVisibilityWaitByCssLocator(smsIbShortCode);			
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
