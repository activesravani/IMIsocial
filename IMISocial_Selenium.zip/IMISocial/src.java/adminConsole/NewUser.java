package adminConsole;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import adminConsole.NewItem;
import utils.UserFunctions;


public class NewUser extends NewItem{
	UserFunctions UF = new UserFunctions();

	protected String firstName = "UserModel.FirstName";
	protected String lastName = "UserModel.LastName";
	protected String email = "UserModel.Email";
	protected String permission = "permissionsTree";
	protected String divisions = "//li[starts-with(@id,'tenancy')]";
	protected String divisionName ="//li[starts-with(@id,'tenancy')]/a";
	protected String divisionTree = "//li[starts-with(@id,'tenancy')]/i";
	protected String divisionActions = "//li[starts-with(@id,'tenancy')]/a/span/a";
	protected String brands = "//li[starts-with(@id,'tenancy')]/ul";
	protected String brandName = "//li[starts-with(@id,'group')]/a";
	protected String brandTree = "//li[starts-with(@id,'group')]/i";
	protected String brandActions = "//li[starts-with(@id,'group')]/a/span/a";
	protected String teams = "//li[starts-with(@id,'group')]/ul";
	protected String teamName = "//a[starts-with(@id,'team')]";
	protected String teamActions = "//li[starts-with(@id,'group')]/ul/li/a/span/a";
	protected String duplicateMailError = "//*[@id='dvUserExist']/pre/p";
	
	
	protected String addprivilegebtn = "//*[@id='addPrivilegeBtn']";
	protected String selectedrole = "//*[@id='SelectedRole_chosen']";
	protected String roleOptions = "//*[@id='SelectedRole_chosen']/div/ul/li";
	protected String selectedgroup = "//*[@id='SelectedGroup_chosen']";
	protected String brandOptions = "//*[@id='SelectedGroup_chosen']/div/ul/li";
	protected String brandText = "//*[@id='SelectedGroup_chosen']/div/div/input";
	protected String okBtn ="//*[@id='okAddPrivilegeBtn']";
	protected String cancelBtn ="//*[@id='cancelAddPrivilegeBtn']";
	protected String removeBtn = "//*[@id='testChange']/div/div[2]/input";

	
	public void addPrivilege(){
		try{
			if(elementByXpath(addprivilegebtn).isDisplayed()){
				elementByXpath(addprivilegebtn).click();
				 elementVisibilityWait(elementByXpath(selectedrole));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void bbcroleSelection(String name){
		try{
			if(elementByXpath(selectedrole).isDisplayed()){
				elementByXpath(selectedrole).click();
				 elementsVisibilityWaitByXpath(roleOptions);
				 List<WebElement> links = elementsByXpath(roleOptions);
					for(WebElement link:links){
							String role = link.getText();
							if(role.contains(name)){
								link.click();
								break;
							}
					}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void bbcbrandSelection(String name){
		try{
			if(elementByXpath(selectedgroup).isDisplayed()){
				elementByXpath(selectedgroup).click();
				 elementsVisibilityWaitByXpath(brandOptions);
				 elementByXpath(brandText).sendKeys(name);
				 List<WebElement> links = elementsByXpath(brandOptions);
					for(WebElement link:links){
							String brand = link.getText();
							if(brand.contains(name)){
								link.click();
								elementVisibilityWait(elementByXpath(okBtn));
								break;
							}
					}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void bbcPermissionSave(){
		try{
			if(elementByXpath(okBtn).isDisplayed()){
				elementByXpath(okBtn).click();
				elementVisibilityWait(elementByXpath(removeBtn));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void bbcPermissionCancel(){
		try{
			if(elementByXpath(cancelBtn).isDisplayed()){
				elementByXpath(cancelBtn).click();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void bbcPermissionremove(){
		try{
			if(elementByXpath(removeBtn).isDisplayed()){
				elementByXpath(removeBtn).click();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> orgsList(){
		List<String> strings = new ArrayList<String>();
		try{
			if(elementById(permission).isDisplayed()){
				elementsVisibilityWaitByXpath(divisions);
				List<WebElement> links = elementsByXpath(divisionName);
				System.out.println(links.size());
				for(WebElement link:links){
				    strings.add(link.getText());
				    System.out.println(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public List<String> brandsList(){
		List<String> strings = new ArrayList<String>();
		try{
			if(elementByXpath(brands).isDisplayed()){
				elementsVisibilityWaitByXpath(brands);
				List<WebElement> links = elementsByXpath(brandName);
				for(WebElement link:links){
						String brand = link.getText();
						System.out.println(brand);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public void orgSelection(String name){
		try{
			if(elementById(permission).isDisplayed()){
				elementsVisibilityWaitByXpath(divisions);
				List<WebElement> lis = elementsByXpath(divisionTree);
				List<WebElement> links = elementsByXpath(divisionName);
				for(WebElement link:links){
						String division = link.getText();
						if(division.contains(name)){
							int index =links.indexOf(link);
							lis.get(index).click();
							elementsVisibilityWaitByXpath(brands);
							break;
						}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void brandSelection(String name){
		try{
			if(elementById(permission).isDisplayed()){
				elementsVisibilityWaitByXpath(brands);
				List<WebElement> lis = elementsByXpath(brandTree);
				List<WebElement> links = elementsByXpath(brandName);
				for(WebElement link:links){
						String brand = link.getText();
						if(brand.contains(name)){
							int index =links.indexOf(link);
							System.out.println(index+" "+brand);
							mouseHover(lis.get(index));
							lis.get(index).click();
							elementsVisibilityWaitByXpath(teams);
							break;
						}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void teamSelection(String team){
		try{
			if(elementByXpath(teams).isDisplayed()){
				elementsVisibilityWaitByXpath(teams);
				List<WebElement> tms = elementsByXpath(teamName);
				for(WebElement tm:tms){
					String tmname = tm.getText();
					System.out.println("Team name is: "+tmname);
					if(tmname.contains(team)){
						actions(teamActions,"Curator");
						actions(teamActions,"Publish");
						actions(teamActions,"Dev");
						actions(teamActions,"Reply");
						break;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void actions(String xpath,String action){
		try{
			if(elementByXpath(xpath).isDisplayed()){
				List<WebElement> actions = elementsByXpath(xpath);
				for(WebElement act:actions){
					String actname = act.getText();
					if(actname.contains(action)){
						act.click();
						break;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void basicInfo(){
		try{
			if(elementById(permission).isDisplayed()){
				elementByName(firstName).clear();
				elementByName(firstName).sendKeys("load"+"user");
				elementByName(lastName).clear();
				elementByName(lastName).sendKeys("load"+"user");
				elementByName(email).clear();
				elementByName(email).sendKeys(uniqueMail());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	} 
	
	public void bbcBasicInfo(){
		try{
			if(elementById(firstName).isDisplayed()){
				elementByName(firstName).clear();
				elementByName(firstName).sendKeys("load"+"user");
				elementByName(lastName).clear();
				elementByName(lastName).sendKeys("load"+"user");
				elementByName(email).clear();
				elementByName(email).sendKeys(uniqueMail());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	} 
	
	public String randomMail(){
		String email =null;
		try{
			email = "load"+"user"+UF.randomNumber()+"@mail.com";
		}catch(Exception e){
			e.printStackTrace();
		}
		return email;
	}
	
	public String uniqueMail(){
		String email =null;
		try{
			email = "load"+"user"+UF.timeMilliSeconds()+"@mail.com";
		}catch(Exception e){
			e.printStackTrace();
		}
		return email;
	}

	
	
}
