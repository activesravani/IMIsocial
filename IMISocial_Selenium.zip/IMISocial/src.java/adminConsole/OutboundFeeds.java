package adminConsole;


import org.openqa.selenium.By;


public class OutboundFeeds extends Dashboard{
	By recordsTable = By.id("adminTable_wrapper");
	By tableTop = By.className("top");
	By tableTopOptions = By.cssSelector("div.top>div");
	By tableTopOptionLabel = By.tagName("label");
	By searchInput = By.cssSelector("div.top>div>label>input");


}