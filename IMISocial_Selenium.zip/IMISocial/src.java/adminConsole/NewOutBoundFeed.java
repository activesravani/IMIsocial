package adminConsole;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class NewOutBoundFeed extends Dashboard{
	public String selectTeam;
	By labels = By.cssSelector("div.editor-label");
	By fields = By.cssSelector("div.editor-field");
	By nameField = By.name("FeedModel.Name");
	By descriptionField = By.name("FeedModel.Description");
	By typeField = By.cssSelector("div.editor-field>div");
	By typeFieldDropdown = By.cssSelector("div.editor-field>div>div");
	By typeFieldOptions = By.cssSelector("div.editor-field>div>div>ul>li");
	By teamCheckbox = By.cssSelector("div.editor-field>input");
	By teamlabel = By.cssSelector("div.editor-field>label");
	By pageContent = By.cssSelector("#content-inner > form > div");
	By okBtn = By.cssSelector("div.buttonRow > input");
	By cancelBtn = By.cssSelector("div.buttonRow > a");
	
	By teamSelector = By.xpath("//*[contains(text(),'')]");

	public List<String> labelNames(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(pageContent).isDisplayed()){
				List<WebElement> links = driver.findElements(labels);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean lablePresence(String name){
		boolean label = false;
		try{
			for(String Name:labelNames()){
				if(Name.contains(name)){
					label=true;
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return label;
	}
	
	public List<String> feedTypes(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(typeField).isDisplayed()){
				List<WebElement> links = driver.findElements(typeFieldOptions);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public void feedTypeSelection(String type){
		try{
			if(driver.findElement(typeField).isDisplayed()){
				driver.findElement(typeField).click();
				if(driver.findElement(typeFieldDropdown).isDisplayed()){
					List<WebElement> feeds = driver.findElements(typeFieldOptions);
					for(WebElement feed:feeds){
						if(feed.getText().contains(type)){
							feed.click();				
						}
					}
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void inputDetails(String name, String description){
		try{
			sendKeys(driver.findElement(nameField),name);
			sendKeys(driver.findElement(descriptionField),description);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void teamSelection(String type){
		try{
			List<WebElement> links = driver.findElements(teamlabel);
			for(WebElement link:links){
				if(link.getText().contains(type)){
					link.click();
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
		
	}
	
	public void teamSelectionByName(String type){
		try{
			List<WebElement> links = driver.findElements(teamSelector);
			for(WebElement link:links){
				if(link.getText().contains(type)){
					link.click();
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
		
	}
	
	public void saveNewItem(){
		try{
			pageScrollToElement(driver.findElement(okBtn));
			if(driver.findElement(okBtn).isEnabled()){
				elementClick(driver.findElement(okBtn));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void cancelNewItem(){
		try{
			pageScrollToElement(driver.findElement(cancelBtn));
			if(driver.findElement(cancelBtn).isEnabled()){
				elementClick(driver.findElement(cancelBtn));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> teams(){
		List<String> strings = new ArrayList<String>();
		try{
			List<WebElement> links = driver.findElements(teamlabel);
			for(WebElement link:links){
			    strings.add(link.getText());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
}
