package adminConsole;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author sravani.a
 *
 */
public class NewBrand extends NewItem{
	protected String brandName = "GroupModel.Name";
	protected String brandDescription = "GroupModel.Description";
	protected String branddistId ="GroupModel.DistId";
	String selectOrg = "#SelectedTenancy_chosen>a> span";
	String selectOrgDropDown ="chosen-drop";
	String autoSelectOrg ="//*[@id='SelectedTenancy_chosen']/div/div/input";
	String searchResultsOrgs = "#SelectedTenancy_chosen>div>ul>li";
	
	public void selectTenancy(String name){
		try{
			elementByCss(selectOrg).click();
			if(elementByClass(selectOrgDropDown).isDisplayed()){
				elementVisibilityWait(elementByXpath(autoSelectOrg));
				sendKeys(elementByXpath(autoSelectOrg),name);
				elementVisibilityWait(elementByClass(selectOrgDropDown));
				List<WebElement> links = elementsByCss(searchResultsOrgs);
				for(WebElement link:links){
					if(link.getText().contains(name)){
						link.click();
						break;
					}
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public List<String> orgsList(){
		List<String> strings = new ArrayList<String>();
		try{
			if(elementByClass(selectOrgDropDown).isDisplayed()){
				elementsVisibilityWaitByCss(searchResultsOrgs);
				List<WebElement> links = elementsByCss(searchResultsOrgs);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	

}
