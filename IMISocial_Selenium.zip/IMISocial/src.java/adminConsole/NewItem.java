package adminConsole;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class NewItem extends Dashboard{
	
	By pageContent = By.cssSelector("#content-inner > form > div");
	By labels = By.cssSelector("div.editor-label");
	
	public List<String> labelNames(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(pageContent).isDisplayed()){
				List<WebElement> links = driver.findElements(labels);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean lablePresence(String name){
		boolean label = false;
		try{
			for(String Name:labelNames()){
				if(Name.contains(name)){
					label=true;
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return label;
	}
	
	public void inputDetails(String Name,String Description,String name, String description){
		try{
			sendKeys(elementByName(Name),name);
			sendKeys(elementByName(Description),description);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void saveNewItem(){
		try{
			pageScrollToElement(driver.findElement(okBtn));
			if(driver.findElement(okBtn).isEnabled()){
				elementClick(driver.findElement(okBtn));
				webDriverWait(driver.findElement(pageHeader),"Manage");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void cancelNewItem(){
		try{
			pageScrollToElement(driver.findElement(cancelBtn));
			if(driver.findElement(cancelBtn).isEnabled()){
				elementClick(driver.findElement(cancelBtn));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	

}
