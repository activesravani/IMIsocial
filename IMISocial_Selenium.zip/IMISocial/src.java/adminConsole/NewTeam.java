package adminConsole;

import java.util.List;

import org.openqa.selenium.WebElement;

public class NewTeam extends NewItem{
	protected String teamName = "Team.Name";
	protected String teamDescription = "Team.Description";
	String selectParent = "#SelectedParentEntity_chosen>a>span";
	String selectParentDropDown ="chosen-drop";
	String autoSelectParent ="//*[@id='SelectedParentEntity_chosen']/div/div/input";
	String searchResultsParents = "#SelectedParentEntity_chosen>div>ul> li";
	protected String tagsName="Team.TagsAsCsv";
	String flagsSection="//*[@id='content-inner']/form/div/div[5]/div[2]/div";
	String flagsCheckbox ="//*[@id='content-inner']/form/div/div[5]/div[2]/div/input";
	String flags = "//*[@id='content-inner']/form/div/div[5]/div[2]/div/label/img";

	
	public void selectParentBrand(String name){
		try{
			elementVisibilityWait(elementByCss(selectParent));
			elementByCss(selectParent).click();
			if(elementByClass(selectParentDropDown).isDisplayed()){
				elementVisibilityWait(elementByXpath(autoSelectParent));
				sendKeys(elementByXpath(autoSelectParent),name);
				elementVisibilityWait(elementByClass(selectParentDropDown));
				List<WebElement> links = elementsByCss(searchResultsParents);
				for(WebElement link:links){
					if(link.getText().contains(name)){
						link.click();
						break;
					}
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void flagSelection(String color){
		try{
			elementsVisibilityWaitByXpath(flagsSection);
			List<WebElement> checkboxes = elementsByXpath(flagsCheckbox);
			List<WebElement> flag = elementsByXpath(flags);
			for(int i=0;i<=flag.size();i++){
				if(flag.get(i).getAttribute("title").equals(color)){
					System.out.println(checkboxes.get(i).isEnabled());
					if(checkboxes.get(i).isEnabled()){
						break;
					}else{
						checkboxes.get(i).click();
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public boolean flagSelectionStatus(String color){
		boolean flagStatus=false;
		try{
			elementsVisibilityWaitByXpath(flagsSection);
			List<WebElement> checkboxes = elementsByXpath(flagsCheckbox);
			List<WebElement> flag = elementsByXpath(flags);
			for(int i=0;i<=flag.size();i++){
				if(flag.get(i).getAttribute("title").equals(color)){
					System.out.println(checkboxes.get(i).isEnabled());
					flagStatus=checkboxes.get(i).isEnabled();
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return flagStatus;
	}

}
