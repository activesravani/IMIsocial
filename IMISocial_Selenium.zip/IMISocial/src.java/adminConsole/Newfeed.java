package adminConsole;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Newfeed extends NewItem{
	
	
	protected String nameField = "FeedModel.Name";
	protected String descriptionField = "FeedModel.Description";
	By typeField = By.cssSelector("div.editor-field>div");
	By typeFieldDropdown = By.cssSelector("div.editor-field>div>div");
	By typeFieldOptions = By.cssSelector("div.editor-field>div>div>ul>li");
	By teamCheckbox = By.cssSelector("div.editor-field>input");
	By teamlabel = By.xpath("//*[@id='content-inner']/form/div/div[4]/div[2]/label");
	By pageContent = By.cssSelector("#content-inner > form > div");
	
	public List<String> feedTypes(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(typeField).isDisplayed()){
				List<WebElement> links = driver.findElements(typeFieldOptions);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public void feedTypeSelection(String type){
		try{
			if(driver.findElement(typeField).isDisplayed()){
				driver.findElement(typeField).click();
				if(driver.findElement(typeFieldDropdown).isDisplayed()){
					List<WebElement> feeds = driver.findElements(typeFieldOptions);
					for(WebElement feed:feeds){
						if(feed.getText().contains(type)){
							feed.click();				
						}
					}
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void teamSelection(){
		try{
			List<WebElement> links = driver.findElements(teamlabel);
			for(WebElement link:links){
				pageScrollToElement(link);
				if(link.getText().contains("TestTeam - Sravani (LIVE TEST Brand - 2017)")){
					elementClick(link);
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
		
	}
	
	public void teamSelectionByName(String type){
		try{
			if(elementByName(type).isDisplayed()){
				pageScrollToElement(elementByName(type));
				elementByName(type).click();
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
		
	}
	
	public List<String> teams(){
		List<String> strings = new ArrayList<String>();
		try{
			List<WebElement> links = driver.findElements(teamlabel);
			for(WebElement link:links){
			    strings.add(link.getText());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
}
