package adminConsole;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.HomePage;


public class Dashboard extends HomePage{
	By navItems = By.cssSelector("#side-nav> ul>li");
	
	By navItem = By.cssSelector("#side-nav ");
	By navItemsLinks = By.cssSelector("#side-nav>ul>li>div");
	
	By navItemsLinks1 = By.cssSelector("#side-nav>ul>li>a");
	By navItemsLinks1Class = By.cssSelector("#side-nav>ul>li>a>div");

	
	By navItemsArrow = By.cssSelector("#side-nav>ul>li>div>img");
	By navSubItems = By.cssSelector("#side-nav>ul>li>ul");
	By navSubItemsArrowDown = By.cssSelector("[contains(@src,'/content/images/curationconsole/arrow_down.gif')]");
	By navItemsArrowRight=By.cssSelector("[contains(@src,'/content/images/curationconsole/arrow_right.gif')]");
	By navSubItemsLinks = By.cssSelector("#side-nav>ul>li>ul>li>a");
	
	By breadCrumb = By.className("breadcrumb");
	By breadCrumbLinks = By.cssSelector("#content-inner>form>ul>li>a");
	By breadCrumbSelectedLink = By.className("selectedPage");
	
	By newItemButton = By.cssSelector("#content-inner>a");
	By secondHeader = By.tagName("h2");

	By recordTable = By.id("adminTable");
	By tableLength = By.cssSelector("#adminTable_length> label>select");
	By tableLengthOptions = By.cssSelector("#adminTable_length> label>select>option");
	By tableInfo = By.cssSelector("#adminTable_info");
	By tableBody=By.cssSelector("#adminTable_wrapper");
	By tableColumns = By.tagName("th");
	By tableColumnSort = By.className("sorting_disabled");
	By tableRows = By.tagName("tr");
	By tableActions = By.cssSelector("#adminTable > tbody > tr>td>a");
	
	
	String deleteBtns = "//*[@id='adminTable']/tbody/tr/td[1]/a[2]/img";
	String editBtns = "//*[@id='adminTable']/tbody/tr/td[1]/a[1]/img";
	String downloadCsvBtns = "//*[@id='adminTable']/tbody/tr/td[1]/a[3]/img";
	
	
	By deleteRecordDialog = By.cssSelector("body > div.ui-dialog.ui-widget.ui-widget-content.ui-corner-all.ui-front.ui-dialog-buttons");
	By deleteRecordDialogHeader= By.cssSelector("#ui-id-2");
	By deleteRecordDialogText = By.cssSelector("#ui-id-1");
	By deleteRecordDialogActionBtn = By.xpath("/html/body/div[4]/div[3]/div/button/span");

	By okBtn = By.cssSelector("div.buttonRow > input");
	By cancelBtn = By.cssSelector("div.buttonRow > a");
	
	By tableRecordName = By.cssSelector("#adminTable > tbody > tr> td.sorting_1");
	
	
	By searchbar = By.cssSelector("#adminTable_filter > label > input[type='search']");
	
	By showHiddenBtn = By.cssSelector("#buttonRow>a");
	By contentSourcesLink = By.id("ContentSources");
	By pipelineFiltersLink = By.id("PipelineFilters");
	
	By shortCodesLink= By.id("ShortCodes");
	By outboundShortCodesLink= By.id("OutboundShortCodes");
	By activeUsers = By.id("ActiveUsers");
	
	By selectedTabColor = By.cssSelector("#side-nav>ul>li>ul>li>a>div>span");
	
	
		
	public List<String> breadCrumbLinkText(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(breadCrumb).isDisplayed()){
				List<WebElement> links = driver.findElements(breadCrumbLinks);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean breadCrumbLinksText(String text){
		boolean linkTextPresence = false;
		try{
			List<String> links = breadCrumbLinkText();
			for(String link:links){
				if(link.contains(text)){
					linkTextPresence=true;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return linkTextPresence;
	}
	
	public String breadCrumbSelectedLinkText(){
		String slectedLink = null;
		try{
			if(driver.findElement(breadCrumb).isDisplayed()){
				slectedLink = driver.findElement(breadCrumbSelectedLink).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return slectedLink;
	}
	
	public List<String> navItemLinkText(){
		List<String> strings = new ArrayList<String>();
		try{
			elementVisibilityWait(driver.findElement(navItem));
			if(driver.findElement(navItem).isDisplayed()){
				List<WebElement> links = driver.findElements(navItemsLinks);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean navItemLinksText(String text){
		boolean linkTextPresence = false;
		try{
			List<String> links = navItemLinkText();
			for(String link:links){
				if(link.contains(text)){
					linkTextPresence=true;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return linkTextPresence;
	}
	
	public void navItemlinkClick(String text){
		try{
			List<WebElement> links = driver.findElements(navSubItemsLinks);
			for(WebElement link:links){
				if(link.getAttribute("title").contains(text) && link.isEnabled()){
					elementClick(link);
					break;
					
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> navItemLinkTexts1(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(navItem).isDisplayed()){
				List<WebElement> links = driver.findElements(navItemsLinks1);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean navItemLinksText1(String text){
		boolean linkTextPresence = false;
		try{
			List<String> links = navItemLinkText();
			for(String link:links){
				if(link.contains(text)){
					linkTextPresence=true;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return linkTextPresence;
	}
	
	public void navigationPage(String text){
		try{
			List<WebElement> links = driver.findElements(navItemsLinks1);
			for(WebElement link:links){
				if(link.getAttribute("title").contains(text)){
					elementClick(link);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOfElementLocated(recordTable));			
					break;
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean navigationSelectedPage(String text){
		boolean pageSelection = false;
		try{
			List<WebElement> links = driver.findElements(navItemsLinks1Class);
			for(WebElement link:links){
				if(link.getAttribute("class").contains(text)){
					pageSelection = true;
					break;
				}
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return pageSelection;
	}
	
	public String arrowImgdirection(WebElement element){
		String src = null;
		try{
			if(element.getAttribute("src")!=""){
				src=element.getAttribute("src");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return src;
	}
	
	public String subItemsHieght(WebElement element){
		String height = null;
		try{
			if(element.getAttribute("style")!="height: 0px;"){
				height=element.getAttribute("style");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return height;
	}
	
	public void expandNavItem(String text){
		try{
			List<WebElement> links = driver.findElements(navItemsArrow);
			for(WebElement link:links){
				if(link.getAttribute("title").contains(text)){
					elementClick(link);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(navSubItems));	
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void collapseNavItem(String text){
		try{
			List<WebElement> links = driver.findElements(navItemsArrow);
			for(WebElement link:links){
				if(link.getAttribute("title").contains(text)){
					elementClick(link);
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.invisibilityOfElementLocated(navSubItems));	
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> navSubItemLinkText(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(navSubItems).isDisplayed()){
				List<WebElement> links = driver.findElements(navSubItemsLinks);
				for(WebElement link:links){
				    strings.add(link.getAttribute("title"));
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean locatorPresence(String attribute){
		boolean linkTextPresence = false;
		try{
			if(elementById(attribute).isDisplayed()){
				linkTextPresence=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return linkTextPresence;
	}
	
	public boolean navSubItemLinksText(String text){
		boolean linkTextPresence = false;
		try{
			if(driver.findElement(navSubItems).isDisplayed()){
				List<WebElement> links = driver.findElements(navSubItemsLinks);
				for(WebElement link:links){
					mouseHover(link);
					if(link.getAttribute("title").contains(text)){
						linkTextPresence=true;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return linkTextPresence;
	}
	 
	
	
	public String newItemButtonName(){
		String name=null;
		try{
			if(driver.findElement(newItemButton).isDisplayed()){
				name=driver.findElement(newItemButton).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return name;
	}
	
	public void newItemPage(String text){
		try{
			if(newItemButtonName().contains(text)){
				if(driver.findElement(newItemButton).isEnabled()){
					elementClick(driver.findElement(newItemButton));
					WebDriverWait wait = new WebDriverWait(driver, 30);
					wait.until(ExpectedConditions.visibilityOfElementLocated(cancelBtn));	
				}
			}
		}catch(Exception e){
			
		}
	}
	
	public boolean searchRecord(String name){
		boolean recordPresence = false;
		try{
			if(driver.findElement(searchbar).isDisplayed()){
				driver.findElement(searchbar).sendKeys(name);
				List<String> names = recordName();
				for(String Name:names){
					if(Name.contains(name)){
						recordPresence = true;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return recordPresence;
	}
	
	public void searchAndDelete(String name){
		try{
			do{
				driver.findElement(searchbar).sendKeys(name);
				List<String> names = recordName();
				List<WebElement> deleteButtons = elementsByXpath(deleteBtns);
				for(int i=0;i<names.size();i++){
					if(names.get(i).substring(0, 4).equals(name)){
						deleteButtons.get(i).click();
						tableActionList("Delete");
						deleteDialogActions("OK");
					}
				}
			}while(recordName().size()!=0);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> tableLengthOptionsText(){
		List<String> strings = new ArrayList<String>();
		try{
			pageScrollToElement(driver.findElement(newItemButton));
			if(driver.findElement(tableLength).isDisplayed()){
				elementClick(driver.findElement(tableLength));
				List<WebElement> links = driver.findElements(tableLengthOptions);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public boolean tableLengthOption(String text){
		boolean option = false;
		List<String> strings = tableLengthOptionsText();
		try{
			for(String optionText:strings){
				if(optionText.equals(text)){
					option=true;
				}

			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return option;
	}
	
	public void tableLengthSelection(String text){
		try{
			if(driver.findElement(tableLength).isDisplayed()){
				mouseHover(driver.findElement(tableLength));			
				driver.findElement(tableLength).click();
				List<WebElement> links = driver.findElements(tableLengthOptions);
				for(WebElement link:links){
					if(link.getText().equals(text)){
						link.click();
						WebDriverWait wait = new WebDriverWait(driver, 30);
						wait.until(ExpectedConditions.visibilityOfElementLocated(tableInfo));			
						break;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> tableHeadersText(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				mouseHover(driver.findElement(recordTable));
				List<WebElement> links = driver.findElements(tableColumns);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public String recorddInfo(){
		String info=null;
		try{
			scrolltoLastElement(driver.findElement(tableInfo));
			mouseHover(driver.findElement(tableInfo));
			if(driver.findElement(tableInfo).isDisplayed()){
				info = driver.findElement(tableInfo).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return info;
	}
	
	public boolean recorddInfoCheck(String count){
		boolean info=false;
		try{
			if(recorddInfo().contains(count)){
				info=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return info;
	}
	
	
	public boolean tableHeaderPresence(String text){
		boolean option = false;
		List<String> strings = tableHeadersText();
		try{
			for(String optionText:strings){
				if(optionText.equals(text)){
					option=true;
				}

			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return option;
	}
	
	public void tablesorting(String header){
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				List<WebElement> links = driver.findElements(tableColumns);
				mouseHover(driver.findElement(tableColumns));
				for(WebElement link:links){
					if(link.getText().equals(header)){
						elementClick(link);
						selectSortingOrder(header,"asc");
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String tableHeaderSortName(String header){
		String order=null;
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				List<WebElement> links = driver.findElements(tableColumns);
				for(WebElement link:links){
					if(link.getText().equals(header)){
						order = link.getAttribute("aria-sort");
					}
				}			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return order;
	}
	
	public String tableHeaderActiveSortName(String header){
		String order=null;
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				List<WebElement> links = driver.findElements(tableColumns);
				for(WebElement link:links){
					if(link.getText().equals(header)){
						order = link.getAttribute("aria-label");
					}
				}			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return order;
	}
	public String pageHeader(){
		String header=null;
		try{
			if(driver.findElement(secondHeader).getText()!=""){
				header = driver.findElement(secondHeader).getText();
			}		
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	
	
	public void recordSorting(){
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				List<WebElement> links = driver.findElements(tableColumns);
				for(WebElement link:links){
					mouseHover(link);
					if(sortingOrder(link.getText())!=""){
						elementClick(link);
					}
				}	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	public void sorting(String header){
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				List<WebElement> links = driver.findElements(tableColumns);
				for(WebElement link:links){
					if(link.getText().equals(header)){
						if(sortingOrder(header)!=""){
							elementClick(link);
							WebDriverWait wait = new WebDriverWait(driver, 30);
							wait.until(ExpectedConditions.elementToBeClickable(link));	
							
						}
						
					}
				}	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public String sortingOrder(String header){
		String order = null;
		try{
			if(driver.findElement(recordTable).isDisplayed()){
				List<WebElement> links = driver.findElements(tableColumns);
				for(WebElement link:links){
					if(link.getText().equals(header)){
						order=link.getAttribute("class");
					}
				}	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return order;
		
	}
	
	
	public boolean verifySortingOrder(String header, String order){
		boolean sortingOrder=false;
		try{
			if(sortingOrder(header).contains(order)){
				sortingOrder=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return sortingOrder;
	}
	
	public void selectSortingOrder(String header, String order){

		try{			
			sorting(header);
			if(sortingOrder(header).contains(order)){
				sorting(header);
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void tableActionList(String action){
		try{
			if(driver.findElement(tableBody).isDisplayed()){
				List<WebElement> links = driver.findElements(tableActions);
				for(WebElement link:links){
					if(link.getAttribute("title").contains(action)){
						mouseHover(link);
						link.click();
						if(action.contains("edit")){
							WebDriverWait wait = new WebDriverWait(driver, 30);
							wait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(pageHeader), "Edit"));	
							break;
						}else if(action.contains("delete")){
							WebDriverWait wait = new WebDriverWait(driver, 30);
							wait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(deleteRecordDialogHeader), "Delete"));
							deleteDialogActions("OK");
							break;
						}
						
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void deleteDialogActions(String action){
		try{
			if(driver.findElement(deleteRecordDialog).isDisplayed()){
				if(driver.findElement(deleteRecordDialogHeader).getText().equals("Delete")){
					if(driver.findElement(deleteRecordDialogActionBtn).getText().equals(action)){
						driver.findElement(deleteRecordDialogActionBtn).click();
						webDriverWait(driver.findElement(searchbar),"");
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public List<String> recordName(){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(tableBody).isDisplayed()){
				List<WebElement> links = driver.findElements(tableRecordName);
				for(WebElement link:links){
				    strings.add(link.getText());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
	
	public List<String> searchRecords(String name){
		List<String> strings = new ArrayList<String>();
		try{
			if(driver.findElement(searchbar).isDisplayed()){
				driver.findElement(searchbar).sendKeys(name);
				if(driver.findElement(tableBody).isDisplayed()){
					List<WebElement> links = driver.findElements(tableRecordName);
					for(WebElement link:links){
					    strings.add(link.getText());
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strings;
	}
}