package adminConsole;

public class NewOrg extends NewItem{
	
	protected String orgName = "TenancyModel.Name";
	protected String orgDesc = "TenancyModel.Description";
	String custRef = "TenancyModel.ImiCustomerRef";
	String logo = "TenancyModel.LogoFile";
	String smallLogo = "TenancyModel_SmallLogoFile";
	String backgroundFile = "TenancyModel.LogoBackgroundFile";
	String backgroundColor = "TenancyModel.BackgroundColor";
	String fontColor = "TenancyModel.ForeGroundColor";


}
