package campaignTests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import campaignConsole.Dashboard;

public class DashBoard extends Dashboard{
	@BeforeTest
	public void campaignHome(){
		landingPage();
		Consoleselection("Campaign Console");
		Login("sravani.a@imimobile.com","July@1993");
		PickVersion();
	}
	
	@Test
	public void newCampaign(){
		sideMenuOptionSelection("Switch Theme");
	}

}
