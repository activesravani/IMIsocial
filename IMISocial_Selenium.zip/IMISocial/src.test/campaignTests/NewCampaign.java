package campaignTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import campaignConsole.CampaignCreation;

public class NewCampaign extends CampaignCreation{
	@BeforeTest
	public void campaignHome(){
		landingPage();
		Consoleselection("Campaign Console");
		Login("sravani.a@imimobile.com","July@1993");
		PickVersion();
	}
	
	@Test
	public void newCampaign(){
		sideMenuOptionSelection("New Campaign");
		newCampaignType("Vote");
		/*//Assert.assertEquals(detailsTab(), "Vote: Details");
		campaignNameEntry("VoteM");
		orgSelection("IMIMobile");
		brandSelection("LIVE TEST Brand - 2017");
		teamSelection("Live Testing Team");*/
		
	}
}
