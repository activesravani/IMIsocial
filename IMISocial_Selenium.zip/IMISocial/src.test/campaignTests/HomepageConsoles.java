package campaignTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.HomePage;

public class HomepageConsoles extends HomePage{
	
	@BeforeTest
	public void campaignHome(){
		landingPage();
		Consoleselection("Campaign Console");
		Login("sravani.a@imimobile.com","July@2017");
		PickVersion();
	}
	@Test(priority=1)
	public void adminConsole(){
		MenuLinkCheck("Admin Console");
		
	}
	

}
