package campaignTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.EditProfile;

public class Profile extends EditProfile{
	@BeforeTest
	public void campaignHome(){
		landingPage();
		Consoleselection("Campaign Console");
		Login("sravani.a@imimobile.com","July@1993");
		PickVersion();
	}
	
	@Test(priority=1)
	public void profileMenu(){
		MenuLinkCheck("Sravani Asireddy");
		Assert.assertEquals(pageHeaderText(), "Edit Profile");
	}
	@Test(priority=2)
	public void breadCrumbAccess(){	
		breadCrumbLinksText("Admin Console");
		Assert.assertEquals(breadCrumbSelectedLinkText(), "Edit Profile");
	}
	@Test(priority=3)
	public void labelValidations(){
		lableCheck("First Name");
		lableCheck("Last Name");
		lableCheck("Privileges");
	}
	@Test(priority=4)
	public void fieldValidations_1(){
		fieldValue("FirstName","");
		Assert.assertEquals(fieldValidationErrorString("First name is required"), "First name is required");
	}
	@Test(priority=5)
	public void fieldValidations_2(){
		pageRefresh();
		fieldValue("LastName","");
		Assert.assertEquals(fieldValidationErrorString("Last name is required"), "Last name is required");
	}
	@Test(priority=6)
	public void fieldValidations(){
		pageRefresh();
		fieldValue("FirstName","");
		fieldValue("LastName","");
		Assert.assertEquals(fieldValidationErrorString("First name is required"), "First name is required");
		Assert.assertEquals(fieldValidationErrorString("Last name is required"), "Last name is required");
	}
}
