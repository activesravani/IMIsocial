package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.NewTeam;

public class CreateTeam extends NewTeam{
	
	@BeforeTest
	public void AdminDashboard(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void ManageTeams()
	{
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		expandNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Teams"), true);
		navItemlinkClick("Teams");
		Assert.assertEquals(pageHeaderText(), "Manage Teams");
		
	}
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageTeams" }, priority=1)
	public void TeamDelete()
	{
		searchAndDelete("ATNO");
	}	
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageTeams" }, priority=2)
	public void TeamCreation()
	{
		
		newItemPage("Create Team");
		Assert.assertEquals(pageHeaderText(), "Create Team");
		Assert.assertEquals(lablePresence("Name"), true);
		Assert.assertEquals(lablePresence("Description"), true);
		Assert.assertEquals(lablePresence("Parent"), true);
		Assert.assertEquals(lablePresence("Comma separated tags"), true);
		Assert.assertEquals(lablePresence("Team flags"), true);
		sendKeys(elementByName(teamName),"ATNT");
		selectParentBrand("ATNB");
		sendKeys(elementByName(teamDescription),"Automation script");
		sendKeys(elementByName(tagsName),"test");
		flagSelection("Yellow");
		Assert.assertEquals(flagSelectionStatus("Yellow"), true);
		saveNewItem();
	}	
	
	//@Test(groups = { "Functional" }, dependsOnMethods = { "ManageTeams" }, priority=3)
	public void TeamUpdate()
	{
		Assert.assertEquals(searchRecord("ATNT"), true);
		tableActionList("edit");
		Assert.assertEquals(lablePresence("Name"), true);
		Assert.assertEquals(lablePresence("Description"), true);
		Assert.assertEquals(lablePresence("Parent"), true);
		Assert.assertEquals(lablePresence("Comma separated tags"), true);
		Assert.assertEquals(lablePresence("Team flags"), true);
		sendKeys(elementByName(teamName),"ATNT_Edit");
		selectParentBrand("ATNB");
		sendKeys(elementByName(teamDescription),"Automation script_Edit");
		sendKeys(elementByName(tagsName),"test_Edit");
		flagSelection("Pink");
		Assert.assertEquals(flagSelectionStatus("Pink"), true);
		saveNewItem();
		Assert.assertEquals(searchRecord("ATNT_Edit"), true);
	}	


}
