package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.Dashboard;

public class Ops extends Dashboard{
	
	@BeforeTest
	public void campaignHome(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	@Test(priority=3)
	public void opsSublinks(){
		Assert.assertEquals(navItemLinksText("Ops"), true);
		expandNavItem("Ops");
		Assert.assertEquals(locatorPresence("ShortCodes"), true);
		collapseNavItem("Ops");
		Assert.assertEquals(locatorPresence("ShortCodes"), false);

	}


}
