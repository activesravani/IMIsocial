package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.HomePage;

public class Login extends HomePage{
	
	@BeforeTest
	public void campaignHome(){
		landingPage();
		Consoleselection("Admin Console");
	}
	
	@Test(priority=1)
	public void validationError1(){
		Login("","");
		Assert.assertEquals(loginPageFieldValidationError(), "Email is required");
	}
	
	@Test(priority=2)
	public void validationError2(){
		Login("sravani.a@","");
		Assert.assertEquals(loginPageFieldValidationError(), "Please enter a valid email address");
	}
	
	@Test(priority=3)
	public void summaryError1(){
		Login("sravani.a@imimobile.com","");
		Assert.assertEquals(loginPageSummaryValidationError(), "The email address or password you entered is incorrect.");
	}
}
