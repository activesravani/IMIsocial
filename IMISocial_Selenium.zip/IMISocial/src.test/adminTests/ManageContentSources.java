package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.Dashboard;

public class ManageContentSources extends Dashboard{
	@BeforeTest
	public void campaignHome(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void tabExpansion(){
		Assert.assertEquals(navItemLinksText("Manage Content Sources"), true);
		expandNavItem("Manage Content Sources");
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "tabExpansion" })
	public void manageContentSources(){
		navItemlinkClick("Content Sources");
		Assert.assertEquals(pageHeaderText(), "Manage Content Sources");
		tableLengthSelection("10");		
		Assert.assertEquals(recorddInfoCheck("10"), true);
		recordSorting();
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "tabExpansion" })
	public void pipeLineFilters(){
		navItemlinkClick("Pipeline Filters");
		System.out.println(pageHeaderText());
		Assert.assertEquals(pageHeaderText(), "Manage Pipeline Filters");
		tableLengthSelection("25");		
		Assert.assertEquals(recorddInfoCheck("25"), true);
		recordSorting();
	}

}
