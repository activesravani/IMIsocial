package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import adminConsole.Newfeed;

public class PageNavigations extends Newfeed{
	
	@BeforeTest
	public void campaignHome(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(priority=1)
	public void outboundFeedsNavigation()
	{
		navigationPage("Outbound Feeds");
		Assert.assertEquals(navigationSelectedPage("menuCurrent"), true);
		Assert.assertEquals(pageHeaderText(), "Outbound Feeds");
		
	}
	
	@Test(priority=2)
	public void tableRecords()
	{
		newItemPage("Create Outbound Feed");
		Assert.assertEquals(pageHeaderText(), "New Outbound Feed");
		Assert.assertEquals(lablePresence("Type"), true);
		Assert.assertEquals(lablePresence("Name"), true);
		Assert.assertEquals(lablePresence("Description"), true);
		feedTypeSelection("Curated");
		inputDetails(nameField,descriptionField,"ACTest","ACTest");
		teamSelection();
		saveNewItem();
		searchRecord("ACTest");
		tableActionList("edit");
		

	}		
		
}
