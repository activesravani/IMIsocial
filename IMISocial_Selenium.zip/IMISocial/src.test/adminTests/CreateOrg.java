package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.NewOrg;
import utils.UserFunctions;

public class CreateOrg extends NewOrg{
	UserFunctions UF = new UserFunctions();
	
	@BeforeTest
	public void AdminDashboard(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void ManageOrgs()
	{
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		expandNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Organisations"), true);
		navItemlinkClick("Organisations");
		Assert.assertEquals(pageHeaderText(), "Manage Organisations");
		
	}
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageOrgs" }, priority=1)
	public void OrgDelete()
	{
		searchAndDelete("ATNO");
	}	
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageOrgs" }, priority=2)
	public void OrgCreation()
	{
		
		newItemPage("Create Organisation");
		Assert.assertEquals(pageHeaderText(), "Create Organisation");
		Assert.assertEquals(lablePresence("Name"), true);
		Assert.assertEquals(lablePresence("Description"), true);
		Assert.assertEquals(lablePresence("Customer Reference is required"), true);
		sendKeys(elementByName(orgName),"ATNO"+UF.currentTime());
		sendKeys(elementByName(orgDesc),"Automation script"+UF.currentTime());
		saveNewItem();
	}	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageOrgs" }, priority=3)
	public void OrgUpdate()
	{
		Assert.assertEquals(searchRecord("ATNO"), true);
		tableActionList("edit");
		sendKeys(elementByName(orgName),"ATNO_Edit"+UF.currentTime());
		sendKeys(elementByName(orgDesc),"Automation script_Edit"+UF.currentTime());
		saveNewItem();
		Assert.assertEquals(searchRecord("Edit"), true);
	}
	
}
