package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.NewBrand;
import utils.UserFunctions;

public class CreateBrand extends NewBrand{
	UserFunctions UF = new UserFunctions();

	
	@BeforeTest
	public void AdminDashboard(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void ManageBrands()
	{
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		expandNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Brands"), true);
		navItemlinkClick("Brands");
		Assert.assertEquals(pageHeaderText(), "Manage Brands");
		
	}
	
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageBrands" }, priority=1)
	public void BrandDelete()
	{
		searchAndDelete("ATNB");
	}		
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageBrands" }, priority=2)
	public void BrandCreation()
	{
		
		newItemPage("Create Brand");
		Assert.assertEquals(pageHeaderText(), "Create Brand");
		Assert.assertEquals(lablePresence("Name"), true);
		Assert.assertEquals(lablePresence("Description"), true);
		Assert.assertEquals(lablePresence("Parent Organisation"), true);
		Assert.assertEquals(lablePresence("DistId"), true);
		sendKeys(elementByName(brandName),"ATNB");
		sendKeys(elementByName(brandDescription),"Automation script");
		sendKeys(elementByName(branddistId),String.valueOf(UF.randomNumber()));
		selectTenancy("ATNO");
		saveNewItem();
	}	
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageBrands" }, priority=3)
	public void BrandUpdate()
	{
		Assert.assertEquals(searchRecord("ATNB"), true);
		tableActionList("edit");
		sendKeys(elementByName(brandName),"ATNB_Edit");
		sendKeys(elementByName(brandDescription),"Automation script_Edit");
		sendKeys(elementByName(branddistId),"3");
		saveNewItem();
		Assert.assertEquals(searchRecord("Edit"), true);
	}	

}
