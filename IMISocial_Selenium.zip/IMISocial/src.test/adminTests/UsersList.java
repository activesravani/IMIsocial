package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import adminConsole.Users;

public class UsersList extends Users{
	
	@BeforeTest
	public void AdminDashboard(){ 
		landingPage();
		/*bbcLogin("sravani.a@imimobile.com","Sep@2017");
		consolePage();*/
	}
	
	//@Test(groups = { "Functional" })
	public void ManageUsers()
	{
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		expandNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Users"), true);
		navItemlinkClick("Users");
		Assert.assertEquals(pageHeaderText(), "Manage Users");
		
	}
	
	
	//@Test(groups = { "Functional" }, dependsOnMethods = { "ManageUsers" }, priority=1,invocationCount = 5)
	public void listView()
	{
		tableLengthSelection("25");		
		Assert.assertEquals(recorddInfoCheck("25"), true);
		recordSorting();
	}	

	
	//@Test(groups = { "Functional" },dependsOnMethods = { "ManageUsers" })
	public void seachUser(){
		searchRecord("loaduser");
		//Assert.assertEquals(searchRecord("sravani asireddy"), true);
	}
	
	//@Test(groups = { "Functional" },dependsOnMethods = { "seachUser" },priority=1)
	public void editUser(){
		tableActionList("edit");
		pwdResetNewUser();
		
	}
	
	@Test
	public void pwdSetNewUser(){
		bbcmultipleUsersLogin();
	}

}
