package adminTests;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.Dashboard;

public class ManagePermissions extends Dashboard{
	@BeforeTest
	public void campaignHome(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void tabExpansion(){
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		expandNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Divisions"), true);
		Assert.assertEquals(navSubItemLinksText("Brands"), true);
		Assert.assertEquals(navSubItemLinksText("Teams"), true);
		Assert.assertEquals(navSubItemLinksText("Users"), true);
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "tabExpansion" }, priority=4)
	public void manageUsers(){
		navItemlinkClick("Users");
		Assert.assertEquals(pageHeaderText(), "Manage Users");
		tableLengthSelection("10");		
		Assert.assertEquals(recorddInfoCheck("10"), true);
		recordSorting();
		searchRecord("sravani");
		tableActionList("edit");
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "tabExpansion" }, priority=1)
	public void manageOrgs(){
		navItemlinkClick("Divisions");
		Assert.assertEquals(pageHeaderText(), "Manage Divisions");
		tableLengthSelection("25");		
		Assert.assertEquals(recorddInfoCheck("25"), true);
		recordSorting();
		searchRecord("IMIMobile");
		tableActionList("edit");
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "tabExpansion" }, priority=2)
	public void manageBrands(){
		navItemlinkClick("Brands");
		Assert.assertEquals(pageHeaderText(), "Manage Brands");
		tableLengthSelection("50");		
		Assert.assertEquals(recorddInfoCheck("50"), true);
		recordSorting();
		searchRecord("Live Testing");
		tableActionList("edit");
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "tabExpansion" }, priority=3)
	public void manageTeams(){
		navItemlinkClick("Teams");
		Assert.assertEquals(pageHeaderText(), "Manage Teams");
		tableLengthSelection("100");		
		Assert.assertEquals(recorddInfoCheck("100"), true);
		recordSorting();	
		searchRecord("Live Testing");
		tableActionList("edit");
	}
	
	
	@AfterTest
	public void managePermissionsTabClose(){
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		collapseNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Divisions"), false);
		Assert.assertEquals(navSubItemLinksText("Brands"), false);
		Assert.assertEquals(navSubItemLinksText("Teams"), false);
		Assert.assertEquals(navSubItemLinksText("Users"), false);
	}
	

}
