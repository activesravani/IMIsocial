package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.Newfeed;

public class OutBoundFeeds extends Newfeed{
	
	@BeforeTest
	public void campaignHome(){ 
		landingPage();
		Consoleselection("Admin Console");
		Login("sravani.a@imimobile.com","July@1993");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void outboundFeedsNavigation()
	{
		navigationPage("Outbound Feeds");
		Assert.assertEquals(navigationSelectedPage("menuCurrent"), true);
		Assert.assertEquals(pageHeaderText(), "Outbound Feeds");
		
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "outboundFeedsNavigation" })
	public void OutboundFeeds(){
		tableLengthSelection("10");		
		Assert.assertEquals(recorddInfoCheck("25"), true);
		recordSorting();
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "outboundFeedsNavigation" })
	public void seachFeed(){
		Assert.assertEquals(searchRecord("Curated liveA"), true);
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "seachFeed" },priority=1)
	public void editFeed(){
		tableActionList("edit");
	}
	
	@Test(groups = { "Functional" },dependsOnMethods = { "seachFeed" }, priority=2)
	public void deleteFeed(){
		outboundFeedsNavigation();
		tableActionList("delete");
//		Assert.assertEquals(searchRecord("Curated liveA"), false);
	}
	//@Test(groups = { "Functional" },dependsOnMethods = { "outboundFeedsNavigation" })
	public void createFeed(){
		tableLengthSelection("10");		
		Assert.assertEquals(recorddInfoCheck("25"), true);
		recordSorting();
	}
}
