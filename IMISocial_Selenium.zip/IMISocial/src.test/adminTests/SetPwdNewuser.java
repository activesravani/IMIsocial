package adminTests;

public class SetPwdNewuser {

}
