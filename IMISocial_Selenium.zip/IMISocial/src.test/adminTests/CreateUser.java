package adminTests;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminConsole.NewUser;
import utils.UserFunctions;

public class CreateUser extends NewUser {
UserFunctions UF = new UserFunctions();

	
	@BeforeTest
	public void AdminDashboard(){ 
		landingPage();
		bbcLogin("sravani.a@imimobile.com","Sep@2017");
		consolePage();
	}
	
	@Test(groups = { "Functional" })
	public void ManageUsers()
	{
		Assert.assertEquals(navItemLinksText("Manage Permissions"), true);
		expandNavItem("Manage Permissions");
		Assert.assertEquals(navSubItemLinksText("Users"), true);
		navItemlinkClick("Users");
		Assert.assertEquals(pageHeaderText(), "Manage Users");
		
	}
	
	
	@Test(groups = { "Functional" }, dependsOnMethods = { "ManageUsers" }, priority=1,invocationCount = 500)
	public void UserCreation()
	{
		newItemPage("Invite New User");
		bbcBasicInfo();
		/*orgSelection("Radio Org");
		brandSelection("BBC Radio 1");
		teamSelection("Radio 1 Breakfast Show");
		saveNewItem();*/
		addPrivilege();
		bbcroleSelection("Campaign Console");
		bbcPermissionSave();
		addPrivilege();
		bbcroleSelection("Brand Administrator");
		bbcbrandSelection("BBC Radio 1");
		bbcPermissionSave();
		addPrivilege();
		bbcroleSelection("Brand Administrator");
		bbcbrandSelection("BBC Sport");
		bbcPermissionSave();
		saveNewItem();
		
	}	
	
	

}
