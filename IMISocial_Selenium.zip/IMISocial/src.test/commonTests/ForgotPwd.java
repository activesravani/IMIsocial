package commonTests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.FotgotPassword;



public class ForgotPwd extends FotgotPassword{
	
	@BeforeClass
	public void campaignHome(){
		landingPage();
		Consoleselection("Campaign Console");
		forgotPasswordlinkClick();
	}
	@Test(priority=1)
	public void URLValidation(){
		Assert.assertEquals(currentURL(), forgotPasswordURL);
	}
	
	@Test(priority=2)
	public void headerValidation(){
		Assert.assertEquals(actionHeaderText(), "Reset Password");
	}
	
	@Test(priority=3)
	public void labelValidation(){
		Assert.assertEquals(lableCheck("Email"), true);
	}
	@Test(priority=4)
	public void fieldValidation_1(){
		fieldValue("EmailAddress","");
		Assert.assertEquals(fieldValidationErrorString(), "Email is required");
	}
	@Test(priority=5)
	public void fieldValidation_2(){
		fieldValue("EmailAddress","sravani");
		Assert.assertEquals(fieldValidationErrorString(), "Please enter a valid email address");
	}
	@Test(priority=6)
	public void backtoLogin(){
		backButton();
	}
}
